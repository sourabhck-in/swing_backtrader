from typing import Dict, Literal, Optional, Tuple, Union

import pandas as pd
import numpy as np


def calculate_adx_custom(
    high: Union[np.ndarray, pd.Series],
    low: Union[np.ndarray, pd.Series],
    close: Union[np.ndarray, pd.Series],
    period: int = 14,
) -> Tuple[np.ndarray, np.ndarray, np.ndarray]:
    """
    Custom ADX calculation following talib-style approach.

    Parameters:
    -----------
    high : array-like
        High prices
    low : array-like
        Low prices
    close : array-like
        Close prices
    period : int, default 14
        Period for calculations

    Returns:
    --------
    Tuple[np.ndarray, np.ndarray, np.ndarray]
        (plus_di, minus_di, adx)
    """
    # Convert to pandas Series if numpy arrays
    if isinstance(high, np.ndarray):
        high = pd.Series(high)
    if isinstance(low, np.ndarray):
        low = pd.Series(low)
    if isinstance(close, np.ndarray):
        close = pd.Series(close)

    # Directional movement
    plus_dm = high.diff()
    minus_dm = -low.diff()

    # Set negative values to 0
    plus_dm = np.where(plus_dm < 0, 0, plus_dm)
    minus_dm = np.where(minus_dm < 0, 0, minus_dm)

    # Convert to Series for pandas methods
    plus_dm = pd.Series(plus_dm, index=high.index)
    minus_dm = pd.Series(minus_dm, index=high.index)

    # True Range
    tr1 = high - low
    tr2 = (high - close.shift(1)).abs()
    tr3 = (low - close.shift(1)).abs()
    frames = [tr1, tr2, tr3]
    true_range = pd.concat(frames, axis=1).max(axis=1)

    # Average True Range using rolling mean
    atr = true_range.rolling(period).mean()

    # Directional Indicators using exponential smoothing
    plus_di = 100 * (plus_dm.ewm(alpha=1 / period, adjust=False).mean() / atr)
    minus_di = 100 * (minus_dm.ewm(alpha=1 / period, adjust=False).mean() / atr)

    # DX and ADX
    dx = (plus_di - minus_di).abs() / (plus_di + minus_di) * 100
    adx = dx.ewm(alpha=1 / period, adjust=False).mean()

    return plus_di.values, minus_di.values, adx.values


def calculate_rsi(
    prices: Union[np.ndarray, pd.Series],
    period: int = 14,
    smoothing_type: str = "wilder",
) -> np.ndarray:
    """
    Calculate Relative Strength Index (RSI) from scratch.

    Parameters:
    -----------
    prices : numpy.ndarray or pandas.Series
        Array of closing prices
    period : int, default 14
        Period for RSI calculation
    smoothing_type : str, default 'wilder'
        Type of smoothing to use ('wilder' or 'ema')

    Returns:
    --------
    numpy.ndarray
        Array of RSI values (0-100)
    """
    # Convert to numpy array if pandas Series
    if isinstance(prices, pd.Series):
        prices = prices.values

    # Ensure we have enough data
    if len(prices) < period + 1:
        return np.full(len(prices), np.nan)

    # Calculate price changes
    price_changes = np.diff(prices)

    # Separate gains and losses
    gains = np.where(price_changes > 0, price_changes, 0)
    losses = np.where(price_changes < 0, -price_changes, 0)

    # Initialize RSI array with NaN values
    rsi = np.full(len(prices), np.nan)

    if smoothing_type == "wilder":
        # Wilder's smoothing - calculate initial averages
        avg_gain = np.mean(gains[:period])
        avg_loss = np.mean(losses[:period])

        # Calculate alpha for Wilder's smoothing
        alpha = 1.0 / period

        # Calculate RSI for the first valid period
        if avg_loss != 0:
            rs = avg_gain / avg_loss
            rsi[period] = 100.0 - (100.0 / (1.0 + rs))
        else:
            rsi[period] = 100.0 if avg_gain > 0 else 50.0

        # Apply Wilder's smoothing for remaining values
        for i in range(period + 1, len(prices)):
            avg_gain = alpha * gains[i - 1] + (1 - alpha) * avg_gain
            avg_loss = alpha * losses[i - 1] + (1 - alpha) * avg_loss

            if avg_loss != 0:
                rs = avg_gain / avg_loss
                rsi[i] = 100.0 - (100.0 / (1.0 + rs))
            else:
                rsi[i] = 100.0 if avg_gain > 0 else 50.0

    elif smoothing_type == "ema":
        # Standard EMA smoothing
        alpha = 2.0 / (period + 1)

        # Calculate initial averages
        avg_gain = np.mean(gains[:period])
        avg_loss = np.mean(losses[:period])

        # Calculate RSI for the first valid period
        if avg_loss != 0:
            rs = avg_gain / avg_loss
            rsi[period] = 100.0 - (100.0 / (1.0 + rs))
        else:
            rsi[period] = 100.0 if avg_gain > 0 else 50.0

        # Apply EMA smoothing for remaining values
        for i in range(period + 1, len(prices)):
            avg_gain = alpha * gains[i - 1] + (1 - alpha) * avg_gain
            avg_loss = alpha * losses[i - 1] + (1 - alpha) * avg_loss

            if avg_loss != 0:
                rs = avg_gain / avg_loss
                rsi[i] = 100.0 - (100.0 / (1.0 + rs))
            else:
                rsi[i] = 100.0 if avg_gain > 0 else 50.0

    return rsi


def calculate_sma(prices: Union[np.ndarray, pd.Series], period: int) -> np.ndarray:
    """
    Calculate Simple Moving Average (SMA).

    Parameters:
    -----------
    prices : numpy.ndarray or pandas.Series
        Array of prices
    period : int
        Period for moving average calculation

    Returns:
    --------
    numpy.ndarray
        Array of SMA values
    """
    # Convert to numpy array if pandas Series
    if isinstance(prices, pd.Series):
        prices = prices.values

    # Ensure we have enough data
    if len(prices) < period:
        return np.full(len(prices), np.nan)

    # Initialize SMA array with NaN values
    sma = np.full(len(prices), np.nan)

    # Calculate SMA using a rolling window
    for i in range(period - 1, len(prices)):
        sma[i] = np.mean(prices[i - period + 1 : i + 1])

    return sma


def calculate_ema(
    prices: Union[np.ndarray, pd.Series], period: int, alpha: Optional[float] = None
) -> np.ndarray:
    """
    Calculate Exponential Moving Average (EMA).

    Parameters:
    -----------
    prices : numpy.ndarray or pandas.Series
        Array of prices
    period : int
        Period for moving average calculation
    alpha : float, optional
        Smoothing factor. If None, uses standard alpha = 2/(period+1)

    Returns:
    --------
    numpy.ndarray
        Array of EMA values
    """
    # Convert to numpy array if pandas Series
    if isinstance(prices, pd.Series):
        prices = prices.values

    # Ensure we have enough data
    if len(prices) < 1:
        return np.full(len(prices), np.nan)

    # Calculate alpha (smoothing factor)
    if alpha is None:
        alpha = 2.0 / (period + 1)

    # Initialize EMA array
    ema = np.full(len(prices), np.nan)

    # First EMA value is the first price
    ema[0] = prices[0]

    # Calculate EMA for remaining values
    for i in range(1, len(prices)):
        ema[i] = alpha * prices[i] + (1 - alpha) * ema[i - 1]

    return ema


def calculate_true_range(
    high: Union[np.ndarray, pd.Series],
    low: Union[np.ndarray, pd.Series],
    close: Union[np.ndarray, pd.Series],
) -> np.ndarray:
    """
    Calculate True Range (TR) for each bar.

    True Range is the maximum of:
    1. Current high - Current low
    2. Absolute value of (Current high - Previous close)
    3. Absolute value of (Current low - Previous close)

    Parameters:
    -----------
    high : numpy.ndarray or pandas.Series
        Array of high prices
    low : numpy.ndarray or pandas.Series
        Array of low prices
    close : numpy.ndarray or pandas.Series
        Array of close prices

    Returns:
    --------
    numpy.ndarray
        Array of True Range values
    """
    # Convert to numpy arrays if pandas Series
    if isinstance(high, pd.Series):
        high = high.values
    if isinstance(low, pd.Series):
        low = low.values
    if isinstance(close, pd.Series):
        close = close.values

    # Ensure arrays are the same length
    if not (len(high) == len(low) == len(close)):
        raise ValueError("High, low, and close arrays must have the same length")

    # Initialize true range array
    true_range = np.zeros(len(high))

    # For the first bar, TR = high - low (no previous close available)
    true_range[0] = high[0] - low[0]

    # Calculate true range for remaining bars
    for i in range(1, len(high)):
        # Three calculations for true range
        hl = high[i] - low[i]  # Current high - low
        hc = abs(high[i] - close[i - 1])  # High - previous close
        lc = abs(low[i] - close[i - 1])  # Low - previous close

        # True range is the maximum of the three
        true_range[i] = max(hl, hc, lc)

    return true_range


def calculate_atr(
    high: Union[np.ndarray, pd.Series],
    low: Union[np.ndarray, pd.Series],
    close: Union[np.ndarray, pd.Series],
    period: int = 14,
    smoothing_type: str = "wilder",
) -> np.ndarray:
    """
    Calculate Average True Range (ATR).

    Parameters:
    -----------
    high : numpy.ndarray or pandas.Series
        Array of high prices
    low : numpy.ndarray or pandas.Series
        Array of low prices
    close : numpy.ndarray or pandas.Series
        Array of close prices
    period : int, default 14
        Period for ATR calculation
    smoothing_type : str, default 'wilder'
        Type of smoothing ('wilder' or 'ema')

    Returns:
    --------
    numpy.ndarray
        Array of ATR values
    """
    # Calculate true range first
    true_range = calculate_true_range(high, low, close)

    # Initialize ATR array with NaN values
    atr = np.full(len(true_range), np.nan)

    # Need at least 'period' values to start calculating ATR
    if len(true_range) < period:
        return atr

    if smoothing_type == "wilder":
        # Wilder's smoothing method (default for ATR)
        # First ATR value is simple average of first 'period' TR values
        atr[period - 1] = np.mean(true_range[:period])

        # Calculate alpha for Wilder's smoothing
        alpha = 1.0 / period

        # Apply Wilder's smoothing for remaining values
        for i in range(period, len(true_range)):
            atr[i] = alpha * true_range[i] + (1 - alpha) * atr[i - 1]

    elif smoothing_type == "ema":
        # Standard EMA smoothing
        alpha = 2.0 / (period + 1)

        # First value
        atr[period - 1] = np.mean(true_range[:period])

        # Apply EMA smoothing
        for i in range(period, len(true_range)):
            atr[i] = alpha * true_range[i] + (1 - alpha) * atr[i - 1]

    else:
        raise ValueError(f"Unsupported smoothing type: {smoothing_type}")

    return atr


def calculate_relative_strength(
    stock_prices: Union[np.ndarray, pd.Series],
    market_prices: Union[np.ndarray, pd.Series],
    lookback_period: int = 10,
    return_period: int = 1,
) -> dict:
    """
    Calculate relative strength of stock compared to market (Nifty).

    Parameters:
    -----------
    stock_prices : numpy.ndarray or pandas.Series
        Array of stock prices
    market_prices : numpy.ndarray or pandas.Series
        Array of market (Nifty) prices
    lookback_period : int, default 10
        Lookback period for calculating relative strength
    return_period : int, default 1
        Period for calculating individual returns (1 = daily)

    Returns:
    --------
    dict
        Dictionary containing:
        - 'relative_strength': array of relative strength values
        - 'stock_returns': array of stock returns over lookback period
        - 'market_returns': array of market returns over lookback period
        - 'rs_positive': boolean array indicating outperformance
        - 'rs_negative': boolean array indicating underperformance
    """
    # Convert to numpy arrays if pandas Series
    if isinstance(stock_prices, pd.Series):
        stock_prices = stock_prices.values
    if isinstance(market_prices, pd.Series):
        market_prices = market_prices.values

    # Ensure arrays are the same length
    if len(stock_prices) != len(market_prices):
        min_len = min(len(stock_prices), len(market_prices))
        stock_prices = stock_prices[:min_len]
        market_prices = market_prices[:min_len]

    # Initialize result arrays
    n = len(stock_prices)
    relative_strength = np.full(n, np.nan)
    stock_returns_lookback = np.full(n, np.nan)
    market_returns_lookback = np.full(n, np.nan)

    # Calculate relative strength for each bar
    for i in range(lookback_period, n):
        # Get price ranges for lookback period
        stock_start = stock_prices[i - lookback_period]
        stock_end = stock_prices[i]
        market_start = market_prices[i - lookback_period]
        market_end = market_prices[i]

        # Calculate returns over lookback period
        if stock_start != 0 and market_start != 0:
            stock_return = ((stock_end - stock_start) / stock_start) * 100
            market_return = ((market_end - market_start) / market_start) * 100

            # Relative strength = Stock return - Market return
            relative_strength[i] = stock_return - market_return
            stock_returns_lookback[i] = stock_return
            market_returns_lookback[i] = market_return

    # Create boolean arrays for easy filtering
    rs_positive = relative_strength > 0
    rs_negative = relative_strength < 0

    return {
        "relative_strength": relative_strength,
        "stock_returns": stock_returns_lookback,
        "market_returns": market_returns_lookback,
        "rs_positive": rs_positive,
        "rs_negative": rs_negative,
    }
