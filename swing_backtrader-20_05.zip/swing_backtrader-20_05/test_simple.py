# test_simple.py - A simple test to verify custom indicators work

import numpy as np
import pandas as pd
from indicators.custom_indicators import (
    calculate_adx_custom,
    calculate_rsi,
    calculate_sma,
    calculate_ema,
    calculate_atr,
    calculate_relative_strength,
)


def test_simple():
    """Simple test of custom indicator functions"""
    # Create sample data
    length = 100
    high = np.random.rand(length) * 100 + 100
    low = high - (np.random.rand(length) * 10)
    close = low + (np.random.rand(length) * (high - low))

    # Test ADX
    print("Testing ADX calculation...")
    plus_di, minus_di, adx = calculate_adx_custom(high, low, close)
    print(f"ADX calculation returned {len(adx)} values")

    # Test RSI
    print("\nTesting RSI calculation...")
    rsi = calculate_rsi(close)
    print(f"RSI calculation returned {len(rsi)} values")

    # Test SMA
    print("\nTesting SMA calculation...")
    sma = calculate_sma(close, 20)
    print(f"SMA calculation returned {len(sma)} values")

    # Test EMA
    print("\nTesting EMA calculation...")
    ema = calculate_ema(close, 20)
    print(f"EMA calculation returned {len(ema)} values")

    # Test ATR
    print("\nTesting ATR calculation...")
    atr = calculate_atr(high, low, close)
    print(f"ATR calculation returned {len(atr)} values")

    # Test Relative Strength
    print("\nTesting Relative Strength calculation...")
    benchmark = close * (1 + (np.random.rand(length) * 0.2 - 0.1))  # Slightly different
    rs_result = calculate_relative_strength(close, benchmark)
    print(
        f"Relative Strength calculation returned {len(rs_result['relative_strength'])} values"
    )

    print("\nAll tests completed successfully!")


if __name__ == "__main__":
    test_simple()
