import numpy as np
import pandas as pd
from indicators.base_indicator import BaseIndicator
from config.bt_parameters import (
    ADX_PERIOD,
    DI_PERIOD,
    RSI_PERIOD,
    MA_PERIOD,
    ATR_PERIOD,
    ATR_MULTIPLE,
    REL_STRENGTH_LOOKBACK,
)


class CustomADXIndicator(BaseIndicator):
    """
    Custom ADX Indicator using your implementation

    Uses the custom ADX calculation method from your existing code.
    """

    def __init__(self, period=None):
        """
        Initialize Custom ADX indicator

        Parameters:
        -----------
        period : int, optional
            Lookback period, defaults to value from bt_parameters.py
        """
        # Use parameter from config if not specified
        self.period = period if period is not None else ADX_PERIOD
        super().__init__("CustomADX", {"period": self.period})

    def calculate(self, data):
        """
        Calculate ADX, +DI, and -DI values using custom implementation

        Parameters:
        -----------
        data : dict
            Price data with 'high', 'low', 'close' arrays

        Returns:
        --------
        dict
            Dictionary with 'adx', 'pdi', 'mdi' arrays
        """
        # Extract data
        high = np.array(data["high"], dtype=float)
        low = np.array(data["low"], dtype=float)
        close = np.array(data["close"], dtype=float)

        # Handle None/NaN values
        high = np.array([h if h is not None else np.nan for h in high])
        low = np.array([l if l is not None else np.nan for l in low])
        close = np.array([c if c is not None else np.nan for c in close])

        # Call the custom implementation
        plus_di, minus_di, adx = calculate_adx_custom(
            high=high, low=low, close=close, period=self.period
        )

        return {"adx": adx, "pdi": plus_di, "mdi": minus_di}


class CustomRSIIndicator(BaseIndicator):
    """
    Custom RSI Indicator using your implementation

    Uses the custom RSI calculation method with Wilder's smoothing.
    """

    def __init__(self, period=None, smoothing_type="wilder"):
        """
        Initialize Custom RSI indicator

        Parameters:
        -----------
        period : int, optional
            Lookback period, defaults to value from bt_parameters.py
        smoothing_type : str, optional
            Type of smoothing to use ('wilder' or 'ema'), by default 'wilder'
        """
        # Use parameter from config if not specified
        self.period = period if period is not None else RSI_PERIOD
        self.smoothing_type = smoothing_type
        super().__init__(
            "CustomRSI", {"period": self.period, "smoothing_type": smoothing_type}
        )

    def calculate(self, data):
        """
        Calculate RSI values using custom implementation

        Parameters:
        -----------
        data : dict
            Price data with 'close' array

        Returns:
        --------
        numpy.ndarray
            Array of RSI values
        """
        # Extract close prices
        close = np.array(data["close"], dtype=float)

        # Handle None/NaN values
        close = np.array([c if c is not None else np.nan for c in close])

        # Call the custom implementation
        rsi = calculate_rsi(
            prices=close, period=self.period, smoothing_type=self.smoothing_type
        )

        return rsi


class CustomSMAIndicator(BaseIndicator):
    """
    Custom SMA Indicator using your implementation

    Calculates Simple Moving Average based on your custom implementation.
    """

    def __init__(self, period=None):
        """
        Initialize Custom SMA indicator

        Parameters:
        -----------
        period : int, optional
            Lookback period, defaults to value from bt_parameters.py
        """
        # Use parameter from config if not specified
        self.period = period if period is not None else MA_PERIOD
        super().__init__("CustomSMA", {"period": self.period})

    def calculate(self, data):
        """
        Calculate SMA values using custom implementation

        Parameters:
        -----------
        data : dict
            Price data with 'close' array

        Returns:
        --------
        numpy.ndarray
            Array of SMA values
        """
        # Extract close prices
        close = np.array(data["close"], dtype=float)

        # Handle None/NaN values
        close = np.array([c if c is not None else np.nan for c in close])

        # Call the custom implementation
        sma = calculate_sma(prices=close, period=self.period)

        return sma


class CustomEMAIndicator(BaseIndicator):
    """
    Custom EMA Indicator using your implementation

    Calculates Exponential Moving Average based on your custom implementation.
    """

    def __init__(self, period=None, alpha=None):
        """
        Initialize Custom EMA indicator

        Parameters:
        -----------
        period : int, optional
            Lookback period, defaults to value from bt_parameters.py
        alpha : float, optional
            Smoothing factor, if None uses standard alpha = 2/(period+1)
        """
        # Use parameter from config if not specified
        self.period = period if period is not None else MA_PERIOD
        self.alpha = alpha
        super().__init__("CustomEMA", {"period": self.period, "alpha": alpha})

    def calculate(self, data):
        """
        Calculate EMA values using custom implementation

        Parameters:
        -----------
        data : dict
            Price data with 'close' array

        Returns:
        --------
        numpy.ndarray
            Array of EMA values
        """
        # Extract close prices
        close = np.array(data["close"], dtype=float)

        # Handle None/NaN values
        close = np.array([c if c is not None else np.nan for c in close])

        # Call the custom implementation
        ema = calculate_ema(prices=close, period=self.period, alpha=self.alpha)

        return ema


class CustomATRIndicator(BaseIndicator):
    """
    Custom ATR Indicator using your implementation

    Calculates Average True Range based on your custom implementation.
    """

    def __init__(self, period=None, smoothing_type="wilder"):
        """
        Initialize Custom ATR indicator

        Parameters:
        -----------
        period : int, optional
            Lookback period, defaults to value from bt_parameters.py
        smoothing_type : str, optional
            Type of smoothing ('wilder' or 'ema'), by default 'wilder'
        """
        # Use parameter from config if not specified
        self.period = period if period is not None else ATR_PERIOD
        self.smoothing_type = smoothing_type
        super().__init__(
            "CustomATR", {"period": self.period, "smoothing_type": smoothing_type}
        )

    def calculate(self, data):
        """
        Calculate ATR values using custom implementation

        Parameters:
        -----------
        data : dict
            Price data with 'high', 'low', 'close' arrays

        Returns:
        --------
        numpy.ndarray
            Array of ATR values
        """
        # Extract data
        high = np.array(data["high"], dtype=float)
        low = np.array(data["low"], dtype=float)
        close = np.array(data["close"], dtype=float)

        # Handle None/NaN values
        high = np.array([h if h is not None else np.nan for h in high])
        low = np.array([l if l is not None else np.nan for l in low])
        close = np.array([c if c is not None else np.nan for c in close])

        # Call the custom implementation
        atr = calculate_atr(
            high=high,
            low=low,
            close=close,
            period=self.period,
            smoothing_type=self.smoothing_type,
        )

        return atr


class CustomRelativeStrengthIndicator(BaseIndicator):
    """
    Custom Relative Strength Indicator using your implementation

    Calculates the relative strength of a stock compared to a benchmark.
    """

    def __init__(self, lookback_period=None, return_period=1):
        """
        Initialize Custom Relative Strength indicator

        Parameters:
        -----------
        lookback_period : int, optional
            Lookback period, defaults to value from bt_parameters.py
        return_period : int, optional
            Period for calculating individual returns, by default 1
        """
        # Use parameter from config if not specified
        self.lookback_period = (
            lookback_period if lookback_period is not None else REL_STRENGTH_LOOKBACK
        )
        self.return_period = return_period
        super().__init__(
            "CustomRelativeStrength",
            {
                "lookback_period": self.lookback_period,
                "return_period": self.return_period,
            },
        )

    def calculate(self, data, benchmark_data):
        """
        Calculate Relative Strength values using custom implementation

        Parameters:
        -----------
        data : dict
            Price data for the stock with 'close' array
        benchmark_data : dict
            Price data for the benchmark with 'close' array

        Returns:
        --------
        dict
            Dictionary with various relative strength metrics
        """
        # Extract close prices
        stock_prices = np.array(data["close"], dtype=float)
        market_prices = np.array(benchmark_data["close"], dtype=float)

        # Handle None/NaN values
        stock_prices = np.array([p if p is not None else np.nan for p in stock_prices])
        market_prices = np.array(
            [p if p is not None else np.nan for p in market_prices]
        )

        # Call the custom implementation
        rs_result = calculate_relative_strength(
            stock_prices=stock_prices,
            market_prices=market_prices,
            lookback_period=self.lookback_period,
            return_period=self.return_period,
        )

        return rs_result


# Include the original functions from your custom_indicators.py
def calculate_adx_custom(
    high: np.ndarray,
    low: np.ndarray,
    close: np.ndarray,
    period: int = 14,
) -> tuple:
    """
    Custom ADX calculation following talib-style approach.

    Parameters:
    -----------
    high : array-like
        High prices
    low : array-like
        Low prices
    close : array-like
        Close prices
    period : int, default 14
        Period for calculations

    Returns:
    --------
    Tuple[np.ndarray, np.ndarray, np.ndarray]
        (plus_di, minus_di, adx)
    """
    # Convert to pandas Series if numpy arrays
    if isinstance(high, np.ndarray):
        high = pd.Series(high)
    if isinstance(low, np.ndarray):
        low = pd.Series(low)
    if isinstance(close, np.ndarray):
        close = pd.Series(close)

    # Directional movement
    plus_dm = high.diff()
    minus_dm = -low.diff()

    # Set negative values to 0
    plus_dm = np.where(plus_dm < 0, 0, plus_dm)
    minus_dm = np.where(minus_dm < 0, 0, minus_dm)

    # Convert to Series for pandas methods
    plus_dm = pd.Series(plus_dm, index=high.index)
    minus_dm = pd.Series(minus_dm, index=high.index)

    # True Range
    tr1 = high - low
    tr2 = (high - close.shift(1)).abs()
    tr3 = (low - close.shift(1)).abs()
    frames = [tr1, tr2, tr3]
    true_range = pd.concat(frames, axis=1).max(axis=1)

    # Average True Range using rolling mean
    atr = true_range.rolling(period).mean()

    # Directional Indicators using exponential smoothing
    plus_di = 100 * (plus_dm.ewm(alpha=1 / period, adjust=False).mean() / atr)
    minus_di = 100 * (minus_dm.ewm(alpha=1 / period, adjust=False).mean() / atr)

    # DX and ADX
    dx = (plus_di - minus_di).abs() / (plus_di + minus_di) * 100
    adx = dx.ewm(alpha=1 / period, adjust=False).mean()

    return plus_di.values, minus_di.values, adx.values


def calculate_rsi(
    prices: np.ndarray,
    period: int = 14,
    smoothing_type: str = "wilder",
) -> np.ndarray:
    """
    Calculate Relative Strength Index (RSI) from scratch.

    Parameters:
    -----------
    prices : numpy.ndarray or pandas.Series
        Array of closing prices
    period : int, default 14
        Period for RSI calculation
    smoothing_type : str, default 'wilder'
        Type of smoothing to use ('wilder' or 'ema')

    Returns:
    --------
    numpy.ndarray
        Array of RSI values (0-100)
    """
    # Convert to numpy array if pandas Series
    if isinstance(prices, pd.Series):
        prices = prices.values

    # Ensure we have enough data
    if len(prices) < period + 1:
        return np.full(len(prices), np.nan)

    # Calculate price changes
    price_changes = np.diff(prices)

    # Separate gains and losses
    gains = np.where(price_changes > 0, price_changes, 0)
    losses = np.where(price_changes < 0, -price_changes, 0)

    # Initialize RSI array with NaN values
    rsi = np.full(len(prices), np.nan)

    if smoothing_type == "wilder":
        # Wilder's smoothing - calculate initial averages
        avg_gain = np.mean(gains[:period])
        avg_loss = np.mean(losses[:period])

        # Calculate alpha for Wilder's smoothing
        alpha = 1.0 / period

        # Calculate RSI for the first valid period
        if avg_loss != 0:
            rs = avg_gain / avg_loss
            rsi[period] = 100.0 - (100.0 / (1.0 + rs))
        else:
            rsi[period] = 100.0 if avg_gain > 0 else 50.0

        # Apply Wilder's smoothing for remaining values
        for i in range(period + 1, len(prices)):
            avg_gain = alpha * gains[i - 1] + (1 - alpha) * avg_gain
            avg_loss = alpha * losses[i - 1] + (1 - alpha) * avg_loss

            if avg_loss != 0:
                rs = avg_gain / avg_loss
                rsi[i] = 100.0 - (100.0 / (1.0 + rs))
            else:
                rsi[i] = 100.0 if avg_gain > 0 else 50.0

    elif smoothing_type == "ema":
        # Standard EMA smoothing
        alpha = 2.0 / (period + 1)

        # Calculate initial averages
        avg_gain = np.mean(gains[:period])
        avg_loss = np.mean(losses[:period])

        # Calculate RSI for the first valid period
        if avg_loss != 0:
            rs = avg_gain / avg_loss
            rsi[period] = 100.0 - (100.0 / (1.0 + rs))
        else:
            rsi[period] = 100.0 if avg_gain > 0 else 50.0

        # Apply EMA smoothing for remaining values
        for i in range(period + 1, len(prices)):
            avg_gain = alpha * gains[i - 1] + (1 - alpha) * avg_gain
            avg_loss = alpha * losses[i - 1] + (1 - alpha) * avg_loss

            if avg_loss != 0:
                rs = avg_gain / avg_loss
                rsi[i] = 100.0 - (100.0 / (1.0 + rs))
            else:
                rsi[i] = 100.0 if avg_gain > 0 else 50.0

    return rsi


def calculate_sma(prices: np.ndarray, period: int) -> np.ndarray:
    """
    Calculate Simple Moving Average (SMA).

    Parameters:
    -----------
    prices : numpy.ndarray or pandas.Series
        Array of prices
    period : int
        Period for moving average calculation

    Returns:
    --------
    numpy.ndarray
        Array of SMA values
    """
    # Convert to numpy array if pandas Series
    if isinstance(prices, pd.Series):
        prices = prices.values

    # Ensure we have enough data
    if len(prices) < period:
        return np.full(len(prices), np.nan)

    # Initialize SMA array with NaN values
    sma = np.full(len(prices), np.nan)

    # Calculate SMA using a rolling window
    for i in range(period - 1, len(prices)):
        window = prices[i - period + 1 : i + 1]
        valid_window = window[~np.isnan(window)]
        if len(valid_window) >= period * 0.5:  # At least half of values should be valid
            sma[i] = np.mean(valid_window)

    return sma


def calculate_ema(prices: np.ndarray, period: int, alpha: float = None) -> np.ndarray:
    """
    Calculate Exponential Moving Average (EMA).

    Parameters:
    -----------
    prices : numpy.ndarray or pandas.Series
        Array of prices
    period : int
        Period for moving average calculation
    alpha : float, optional
        Smoothing factor. If None, uses standard alpha = 2/(period+1)

    Returns:
    --------
    numpy.ndarray
        Array of EMA values
    """
    # Convert to numpy array if pandas Series
    if isinstance(prices, pd.Series):
        prices = prices.values

    # Ensure we have enough data
    if len(prices) < 1:
        return np.full(len(prices), np.nan)

    # Calculate alpha (smoothing factor)
    if alpha is None:
        alpha = 2.0 / (period + 1)

    # Initialize EMA array
    ema = np.full(len(prices), np.nan)

    # Find first valid value (non-NaN)
    for i in range(len(prices)):
        if not np.isnan(prices[i]):
            ema[i] = prices[i]
            start_idx = i + 1
            break
    else:
        # All values are NaN
        return ema

    # Calculate EMA for remaining values
    for i in range(start_idx, len(prices)):
        if np.isnan(prices[i]):
            ema[i] = ema[i - 1]  # Maintain previous EMA if current price is NaN
        else:
            ema[i] = alpha * prices[i] + (1 - alpha) * ema[i - 1]

    return ema


def calculate_true_range(
    high: np.ndarray,
    low: np.ndarray,
    close: np.ndarray,
) -> np.ndarray:
    """
    Calculate True Range (TR) for each bar.

    True Range is the maximum of:
    1. Current high - Current low
    2. Absolute value of (Current high - Previous close)
    3. Absolute value of (Current low - Previous close)

    Parameters:
    -----------
    high : numpy.ndarray or pandas.Series
        Array of high prices
    low : numpy.ndarray or pandas.Series
        Array of low prices
    close : numpy.ndarray or pandas.Series
        Array of close prices

    Returns:
    --------
    numpy.ndarray
        Array of True Range values
    """
    # Convert to numpy arrays if pandas Series
    if isinstance(high, pd.Series):
        high = high.values
    if isinstance(low, pd.Series):
        low = low.values
    if isinstance(close, pd.Series):
        close = close.values

    # Ensure arrays are the same length
    if not (len(high) == len(low) == len(close)):
        raise ValueError("High, low, and close arrays must have the same length")

    # Initialize true range array
    true_range = np.zeros(len(high))

    # For the first bar, TR = high - low (no previous close available)
    true_range[0] = high[0] - low[0]

    # Calculate true range for remaining bars
    for i in range(1, len(high)):
        if np.isnan(high[i]) or np.isnan(low[i]) or np.isnan(close[i - 1]):
            true_range[i] = np.nan
            continue

        # Three calculations for true range
        hl = high[i] - low[i]  # Current high - low
        hc = abs(high[i] - close[i - 1])  # High - previous close
        lc = abs(low[i] - close[i - 1])  # Low - previous close

        # True range is the maximum of the three
        true_range[i] = max(hl, hc, lc)

    return true_range


def calculate_atr(
    high: np.ndarray,
    low: np.ndarray,
    close: np.ndarray,
    period: int = 14,
    smoothing_type: str = "wilder",
) -> np.ndarray:
    """
    Calculate Average True Range (ATR).

    Parameters:
    -----------
    high : numpy.ndarray or pandas.Series
        Array of high prices
    low : numpy.ndarray or pandas.Series
        Array of low prices
    close : numpy.ndarray or pandas.Series
        Array of close prices
    period : int, default 14
        Period for ATR calculation
    smoothing_type : str, default 'wilder'
        Type of smoothing ('wilder' or 'ema')

    Returns:
    --------
    numpy.ndarray
        Array of ATR values
    """
    # Calculate true range first
    true_range = calculate_true_range(high, low, close)

    # Initialize ATR array with NaN values
    atr = np.full(len(true_range), np.nan)

    # Need at least 'period' values to start calculating ATR
    if len(true_range) < period:
        return atr

    # Find first valid window with enough non-NaN values
    for i in range(period, len(true_range)):
        window = true_range[i - period : i]
        valid_window = window[~np.isnan(window)]

        if len(valid_window) >= period * 0.5:  # At least half of values should be valid
            # First ATR value is simple average of first valid window
            atr[i - 1] = np.mean(valid_window)
            start_idx = i
            break
    else:
        # Not enough valid data
        return atr

    if smoothing_type == "wilder":
        # Wilder's smoothing method (default for ATR)
        # Calculate alpha for Wilder's smoothing
        alpha = 1.0 / period

        # Apply Wilder's smoothing for remaining values
        for i in range(start_idx, len(true_range)):
            if np.isnan(true_range[i]) or np.isnan(atr[i - 1]):
                atr[i] = atr[i - 1]  # Maintain previous ATR if current TR is NaN
            else:
                atr[i] = alpha * true_range[i] + (1 - alpha) * atr[i - 1]

    elif smoothing_type == "ema":
        # Standard EMA smoothing
        alpha = 2.0 / (period + 1)

        # Apply EMA smoothing
        for i in range(start_idx, len(true_range)):
            if np.isnan(true_range[i]) or np.isnan(atr[i - 1]):
                atr[i] = atr[i - 1]  # Maintain previous ATR if current TR is NaN
            else:
                atr[i] = alpha * true_range[i] + (1 - alpha) * atr[i - 1]

    else:
        raise ValueError(f"Unsupported smoothing type: {smoothing_type}")

    return atr


def calculate_relative_strength(
    stock_prices: np.ndarray,
    market_prices: np.ndarray,
    lookback_period: int = 10,
    return_period: int = 1,
) -> dict:
    """
    Calculate relative strength of stock compared to market (Nifty).

    Parameters:
    -----------
    stock_prices : numpy.ndarray or pandas.Series
        Array of stock prices
    market_prices : numpy.ndarray or pandas.Series
        Array of market (Nifty) prices
    lookback_period : int, default 10
        Lookback period for calculating relative strength
    return_period : int, default 1
        Period for calculating individual returns (1 = daily)

    Returns:
    --------
    dict
        Dictionary containing:
        - 'relative_strength': array of relative strength values
        - 'stock_returns': array of stock returns over lookback period
        - 'market_returns': array of market returns over lookback period
        - 'rs_positive': boolean array indicating outperformance
        - 'rs_negative': boolean array indicating underperformance
    """
    # Convert to numpy arrays if pandas Series
    if isinstance(stock_prices, pd.Series):
        stock_prices = stock_prices.values
    if isinstance(market_prices, pd.Series):
        market_prices = market_prices.values

    # Ensure arrays are the same length
    if len(stock_prices) != len(market_prices):
        min_len = min(len(stock_prices), len(market_prices))
        stock_prices = stock_prices[:min_len]
        market_prices = market_prices[:min_len]

    # Initialize result arrays
    n = len(stock_prices)
    relative_strength = np.full(n, np.nan)
    stock_returns_lookback = np.full(n, np.nan)
    market_returns_lookback = np.full(n, np.nan)

    # Calculate relative strength for each bar
    for i in range(lookback_period, n):
        # Skip if we have NaN values
        if (
            np.isnan(stock_prices[i])
            or np.isnan(stock_prices[i - lookback_period])
            or np.isnan(market_prices[i])
            or np.isnan(market_prices[i - lookback_period])
        ):
            continue

        # Get price ranges for lookback period
        stock_start = stock_prices[i - lookback_period]
        stock_end = stock_prices[i]
        market_start = market_prices[i - lookback_period]
        market_end = market_prices[i]

        # Calculate returns over lookback period
        if stock_start != 0 and market_start != 0:
            stock_return = ((stock_end - stock_start) / stock_start) * 100
            market_return = ((market_end - market_start) / market_start) * 100

            # Relative strength = Stock return - Market return
            relative_strength[i] = stock_return - market_return
            stock_returns_lookback[i] = stock_return
            market_returns_lookback[i] = market_return

    # Create boolean arrays for easy filtering
    rs_positive = relative_strength > 0
    rs_negative = relative_strength < 0

    return {
        "relative_strength": relative_strength,
        "stock_returns": stock_returns_lookback,
        "market_returns": market_returns_lookback,
        "rs_positive": rs_positive,
        "rs_negative": rs_negative,
    }
