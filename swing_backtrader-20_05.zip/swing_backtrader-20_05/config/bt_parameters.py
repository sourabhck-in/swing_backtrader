# Configuration Parameters for Backtesting

# Securities to backtest
NIFTY_ID = "1333"  # ID of the Nifty index
SYMBOLS = ["1333", "1660", "2303"]  # Example security IDs

# Timeframes
TIMEFRAMES = ["D", "4H"]  # Corresponding to daily and 4h
HIGHER_TIMEFRAME = "D"
LOWER_TIMEFRAME = "4H"

# Date range for backtesting
START_DATE = "2025-01-01"
END_DATE = "2025-05-15"

# Data path
DATA_PATH = "./data"

# Trend indicators parameters
ADX_PERIOD = 14
DI_PERIOD = 14  # Added from parameters.py
ADX_WEAK_THRESHOLD = 20
ADX_STRONG_THRESHOLD = 30

# Momentum indicators parameters
RSI_PERIOD = 7  # Updated to match parameters.py
RSI_OVERSOLD = 40
RSI_OVERBOUGHT = 60

# Moving average parameters
MA_PERIOD = 20  # Added from parameters.py

# Volatility indicators parameters
ATR_PERIOD = 14  # Added from parameters.py
ATR_MULTIPLE = 2  # Added from parameters.py

# Stochastic parameters
STOCH_K_PERIOD = 14
STOCH_D_PERIOD = 3
STOCH_OVERSOLD = 20
STOCH_OVERBOUGHT = 80

# Pivot and support/resistance parameters
PIVOT_LOOKBACK = 5
REL_STRENGTH_LOOKBACK = 10

# Portfolio parameters
INITIAL_CAPITAL = 100000
COMMISSION_RATE = 0.001  # 0.1%
SLIPPAGE = 0.0005  # 0.05%

# Position sizing parameters
RISK_PERCENTAGE = 0.02  # 2% risk per trade
MAX_POSITIONS = 5  # Maximum number of positions
MAX_SECTOR_POSITIONS = 3  # Maximum positions per sector
MAX_PORTFOLIO_HEAT = 0.08  # Maximum risk exposure

# Risk management
MAX_DAYS_IN_TRADE = 10  # Maximum number of trading days to hold a position

# Performance tracking
SAVE_RESULTS = True
RESULTS_PATH = "./results/"
PLOT_EQUITY_CURVE = True
