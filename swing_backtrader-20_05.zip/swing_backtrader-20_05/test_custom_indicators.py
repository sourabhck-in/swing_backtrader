# test_custom_indicators.py

import pandas as pd
import numpy as np
from config.bt_parameters import SYMBOLS, START_DATE, END_DATE, NIFTY_ID
from data.data_processor import prepare_backtest_data
from indicators.indicator_calculator import IndicatorCalculator


def test_custom_indicators():
    """Test custom indicator calculation"""
    # Load synchronized data
    print("Loading and synchronizing data...")
    sync_data = prepare_backtest_data(SYMBOLS, START_DATE, END_DATE)

    # Initialize indicator calculator
    calculator = IndicatorCalculator(sync_data)

    # Print available indicators for debugging
    print("\nAvailable indicator types:")
    for indicator_type in calculator.factory._indicators:
        print(f"  - {indicator_type}")

    # Calculate custom indicators
    print("\nCalculating custom indicators...")

    sample_symbol = SYMBOLS[0]

    try:
        # Calculate ADX
        print(f"Calculating Custom ADX for {sample_symbol}...")
        calculator.calculate_for_symbol(sample_symbol, "D", "custom_adx")

        # Calculate RSI
        print(f"Calculating Custom RSI for {sample_symbol}...")
        calculator.calculate_for_symbol(sample_symbol, "D", "custom_rsi")

        # Calculate SMA
        print(f"Calculating Custom SMA for {sample_symbol}...")
        calculator.calculate_for_symbol(sample_symbol, "D", "custom_sma")

        # Calculate EMA
        print(f"Calculating Custom EMA for {sample_symbol}...")
        calculator.calculate_for_symbol(sample_symbol, "D", "custom_ema")

        # Calculate ATR
        print(f"Calculating Custom ATR for {sample_symbol}...")
        calculator.calculate_for_symbol(sample_symbol, "D", "custom_atr")

        # Calculate Relative Strength compared to Nifty
        if sample_symbol != NIFTY_ID:
            print(
                f"Calculating Custom Relative Strength for {sample_symbol} vs {NIFTY_ID}..."
            )
            calculator.calculate_for_symbol(
                sample_symbol, "D", "custom_rel_strength", benchmark_symbol=NIFTY_ID
            )
    except Exception as e:
        print(f"Error calculating indicators: {e}")
        import traceback

        traceback.print_exc()

    # Check which indicators were successfully calculated
    print("\nChecking calculated indicators:")
    for timeframe in ["D", "4H"]:
        print(f"\n{timeframe} timeframe indicators:")
        if timeframe in sync_data.data[sample_symbol]["indicators"]:
            for indicator_name in sync_data.data[sample_symbol]["indicators"][
                timeframe
            ]:
                values = sync_data.data[sample_symbol]["indicators"][timeframe][
                    indicator_name
                ]
                valid_count = sum(
                    1 for v in values if v is not None and not np.isnan(v)
                )
                print(f"  - {indicator_name}: {valid_count} valid values")
        else:
            print("  No indicators calculated")

    # Find a valid index with indicator values
    valid_index = None

    # Try to find a valid index from any calculated indicator
    indicators_to_check = [
        "custom_adx_adx",
        "custom_rsi",
        "custom_sma",
        "custom_ema",
        "custom_atr",
    ]

    for indicator_name in indicators_to_check:
        values = sync_data.get_indicator(sample_symbol, "D", indicator_name)

        if values is None:
            continue

        for i in range(len(values) - 1, 0, -1):
            if i < len(values) and values[i] is not None and not np.isnan(values[i]):
                valid_index = i
                break

        if valid_index is not None:
            break

    # Print sample indicator values
    if valid_index is not None:
        timestamp = sync_data.timestamps[valid_index]
        print(
            f"\nSample indicator values for {sample_symbol} at index {valid_index} ({timestamp}):"
        )

        # ADX values
        adx = sync_data.get_indicator(sample_symbol, "D", "custom_adx_adx")
        pdi = sync_data.get_indicator(sample_symbol, "D", "custom_adx_pdi")
        mdi = sync_data.get_indicator(sample_symbol, "D", "custom_adx_mdi")

        if adx is not None and pdi is not None and mdi is not None:
            if valid_index < len(adx) and not np.isnan(adx[valid_index]):
                print(f"  ADX: {adx[valid_index]:.2f}")
                print(f"  +DI: {pdi[valid_index]:.2f}")
                print(f"  -DI: {mdi[valid_index]:.2f}")

                # Determine trend
                if pdi[valid_index] > mdi[valid_index]:
                    trend_direction = "UP"
                else:
                    trend_direction = "DOWN"

                if adx[valid_index] < 20:
                    trend_strength = "WEAK"
                elif adx[valid_index] < 30:
                    trend_strength = "MODERATE"
                else:
                    trend_strength = "STRONG"

                print(
                    f"  Trend Analysis: {trend_direction} trend with {trend_strength} strength"
                )

        # RSI value
        rsi = sync_data.get_indicator(sample_symbol, "D", "custom_rsi")
        if (
            rsi is not None
            and valid_index < len(rsi)
            and not np.isnan(rsi[valid_index])
        ):
            print(f"  RSI: {rsi[valid_index]:.2f}")

            if rsi[valid_index] < 30:
                print("    Interpretation: Oversold")
            elif rsi[valid_index] > 70:
                print("    Interpretation: Overbought")
            else:
                print("    Interpretation: Neutral")

        # Moving Average values
        sma = sync_data.get_indicator(sample_symbol, "D", "custom_sma")
        ema = sync_data.get_indicator(sample_symbol, "D", "custom_ema")

        if (
            sma is not None
            and valid_index < len(sma)
            and not np.isnan(sma[valid_index])
        ):
            print(f"  SMA: {sma[valid_index]:.2f}")

        if (
            ema is not None
            and valid_index < len(ema)
            and not np.isnan(ema[valid_index])
        ):
            print(f"  EMA: {ema[valid_index]:.2f}")

        # ATR value
        atr = sync_data.get_indicator(sample_symbol, "D", "custom_atr")
        if (
            atr is not None
            and valid_index < len(atr)
            and not np.isnan(atr[valid_index])
        ):
            print(f"  ATR: {atr[valid_index]:.2f}")

            # Get close price
            close = sync_data.get_at_index(valid_index, sample_symbol, "D", "close")
            if close is not None:
                atr_percentage = (atr[valid_index] / close) * 100
                print(f"    ATR Percentage: {atr_percentage:.2f}% of price")

        # Relative Strength value (if applicable)
        if sample_symbol != NIFTY_ID:
            rs = sync_data.get_indicator(
                sample_symbol, "D", "custom_rel_strength_relative_strength"
            )
            if (
                rs is not None
                and valid_index < len(rs)
                and not np.isnan(rs[valid_index])
            ):
                rs_value = rs[valid_index]
                print(f"  Relative Strength: {rs_value:.2f}%")

                if rs_value > 0:
                    print(f"    Interpretation: Outperforming Nifty by {rs_value:.2f}%")
                else:
                    print(
                        f"    Interpretation: Underperforming Nifty by {-rs_value:.2f}%"
                    )
    else:
        print("\nNo valid indicator values found for demonstration")

    return sync_data, calculator


if __name__ == "__main__":
    test_custom_indicators()
